﻿(function ($, global) {

	var _hash = "!",

	noBackPlease = function () {

		global.location.href += "#";

		setTimeout(function () {

			global.location.href += "!";

		}, 50);

	};

	global.setInterval(function () {

		if (global.location.hash !== _hash) {

			global.location.hash = _hash;
		}

	}, 100);

	global.onload = function () {

		noBackPlease();

		// disables backspace on page except on input fields and textarea.
		$(document.body).keydown(function (e) {

			var elm = e.target.nodeName.toLowerCase();

			if (e.which === 8 && elm !== 'input' && elm !== 'textarea') {

				e.preventDefault();

			}

			// stopping event bubbling up the DOM tree..
			e.stopPropagation();

		});
	};

})(jQuery, window);
