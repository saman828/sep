<?php
	header('Location: ReadyForPayment.php' . "?" . md5(rand())) . "&" . "index";
?>